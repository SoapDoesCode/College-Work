from subprocess import run
run(["python", "-m", "pip", "install", "pynput"])
run(["python", "-m", "pip", "install", "screeninfo"])
run(["python", "-m", "pip", "install", "typing"])